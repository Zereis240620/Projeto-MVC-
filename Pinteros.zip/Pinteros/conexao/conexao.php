<?php
	class Conexao{
		private $dbname = 'pinterosDB';
		private $user = 'root';
		private $pass = '';

		function Connect (){
			try{

				$db = new PDO("mysql:host=localhost;dbname=$this->dbname", $this->user, $this->pass);
				return $db;

			} catch(PDOException $e) {

				echo "Erro na conexao do banco de dados: $e->getMessage";

			}
		}
	}
?>