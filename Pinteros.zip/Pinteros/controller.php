<?php
	if($obj =='usuario'){
		require('controller/usuario.controller.php');
	}
?>