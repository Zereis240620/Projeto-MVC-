<?php
	class UsuarioService{
		private $conexao;
		private $usuario;

		function __construct(Conexao $conexao, Usuario $usuario){
			$this->conexao = $conexao->connect();
			$this->usuario = $usuario;
			
		}

		function create(){
			
				$sql = 'INSERT INTO usuario ( login, nome, senha) VALUES ( :login, :nome, :senha)';
				$stmt = $this->conexao->prepare($sql);
				$stmt->bindValue(':login', $this->usuario->__get('login'));
				$stmt->bindValue(':nome', $this->usuario->__get('nome'));
				$stmt->bindValue(':senha', $this->usuario->__get('senha'));
				return $stmt->execute();

		function read(){
			try{
				if($action[1] = 'ler'){
					$sql = 'SELECT id, login, nome, senha FROM usuario WHERE id=:id';
					$stmt = $this->conexao->prepare($sql);

					$stmt->prepare($sql);
					$stmt->bindValue(':id', $this->usuario->__get('id'));
					$stmt->execute();
				}
				if($action[1] = 'logar'){
					$sql = 'SELECT id, login, nome, senha FROM usuario WHERE login=:login AND senha=:senha';
					$stmt = $this->conexao->connect();

					$stmt->prepare($sql);
					$stmt->bindValue(':login', $this->usuario->__get('login'));
					$stmt->bindValue(':senha', $this->usuario->__get('senha'));
					$stmt->execute();
				}

				return $stmt->fetch(PDO::FETCH_OBJ);

			} catch(PDOException $e) {
				echo "ERRO AO LER USUARIO: $e->getMessage()";
			}
		}

		function update(){
			try{
				$sql = 'UPDATE usuario SET login=:login, nome=:nome, senha=:senha WHERE id=:id';
				$stmt = $this->conexao->prepare($sql);

				$stmt->prepare();
				$stmt->bindValue(':login', $this->usuario->__get('login'));
				$stmt->bindValue(':nome', $this->usuario->__get('nome'));
				$stmt->bindValue(':senha', $this->usuario->__get('senha'));
				$stmt->bindValue(':id', $this->usuario->__get('id'));
				$stmt->execute();
			} catch(PDOException $e) {
				echo "ERRO AO ATUALIZAR USUÁRIO: $e->getMessage()";
			}
		}

		function delete(){
			try{
				$sql = 'DELETE FROM usuario WHERE id=:id';
				$stmt = $this->conexao->prepare($sql);

				$stmt->prepare();
				$stmt->bindValue(':id', $this->usuario->__get('id'));
				$stmt->execute();
			} catch(PDOException $e) {
				echo "ERRO AO DELETAR USUÁRIO: $e->getMessage()";
			}
		}
	}
}
?>