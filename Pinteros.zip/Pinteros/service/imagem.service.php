<?php
	class ImagemService{
		private $conexao;
		private $imagem;

		function __construct(){
			$this->conexao = new Conexao;
			$this->imagem = new Imagem;
		}

		function read(){
			try{
				$sql = 'SELECT id, nome, dataUp, ext, idUsu FROM imagem WHERE id=:id';
				$stmt = $this->conexao->connect();

				$stmt->prepare($sql);
				$stmt->bindValue(':id', $this->imagem->__get('id'));
				$stmt->execute();

				return $stmt->fetch(PDO::FETCH_OBJ);
				
			} catch(PDOException $e) {
				echo "ERRO AO BUSCAR IMAGEM: $e->getMessage()";
			}
		}

		function create(){
			try{
				$sql = 'INSERT INTO imagem (id, nome, dataUp, ext, idUsu) VALUES (:id, :nome, :dataUp, :ext, :idUsu)';
				$stmt = $this->conexao->connect();

				$stmt->prepare($sql);
				$stmt->bindValue(':id', null);
				$stmt->bindValue(':nome', $this->imagem->__get('nome'));
				$stmt->bindValue(':dataUp', $this->imagem->__get('dataUp'));
				$stmt->bindValue(':ext', $this->imagem->__get('ext'));
				$stmt->bindValue(':idUsu', $this->imagem->__get('id'));
				$stmt->execute();
			} catch(PDOException $e) {
				echo "ERRO AO UPAR IMAGEM: $e->getMessage()";
			}
		}

		function update(){
			try{
				$sql = "UPDATE imagem SET nome=:nome, dataUp=:dataUp, ext=:ext, idUsu=:idUsu";
				$stmt = $this->conexao->connect();

				$stmt->prepare($sql);
				$stmt->bindValue(':nome', $this->imagem->__get('nome'));
				$stmt->bindValue(':dataUp', $this->imagem->__get('dataUp'));
				$stmt->bindValue(':ext', $this->imagem->__get('ext'));
				$stmt->bindValue(':idUsu', $this->imagem->__get('idUsu'));
			} catch(PDOException $e) {
				echo "ERRO AO ATUALIZAR IMAGEM: $e->getMessage()";
			}
		}

		function delete(){
			try{
				$sql = 'DELETE FROM imagem WHERE id=:id';
				$stmt = $this->conexao->connect();

				$stmt->bindValue(':id', $this->imagem->__get('id'));
			} catch(PDOException $e) {
				echo "ERRO AO DELETAR IMAGEM: $e->getMessage()";
			}
		}
	}
?>