<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/materialize.css">
	<link rel="stylesheet" type="text/css" href="css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<meta name='viewport' content='width=device-width, initial-scale=1.0'/>
	
	<title>Pinteros</title>

</head>
<body class='yellow darken-3'>

	<div class="container">
		<?php
			if (isset($_GET['link'])){
				$link = $_GET['link'];
			}

			$url[1] = 'home.php';
			$url[2] = 'logar.php';
			$url[3] = 'cadastro.php';

			if(!empty($link)){
				if(file_exists($url[$link])){
					include($url[$link]);
				}
			} else {
				trim(include('cadastrar.php'));
			}
		?>		
	</div>

	<script type="text/javascript" src='js/jquery-3.3.1.js'></script>
	<script type="text/javascript" src='js/materialize.js'></script>
	<script type="text/javascript" src='js/materialize.min.js'></script>
	<script type="text/javascript" src="js/index.js"></script>

</body>
</html>