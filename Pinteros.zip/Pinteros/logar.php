<div class="row">
	<form action='login.php' method="POST">
		<div class="input-field">
			<input type="text" name="login">
			<label for="login">Login</label>
		</div>
		<div class="input-field">
			<input type="password" name="senha">
			<label for="senha">Senha</label>
		</div>
		<button class="btn waves-effect" type="submit">Logar</button>
	</form>
</div>