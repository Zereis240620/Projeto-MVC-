<?php
	class Imagem{
		private $id;
		private $nome;
		private $dataUp;
		private $ext;
		private $idUsu;

		function __get($atributo){
			return $this->atributo;
		}

		function __set($atributo, $valor){
			$this->atributo = $valor;
			return $this;
		}
	}
?>