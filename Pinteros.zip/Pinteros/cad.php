<?php
    
	$obj = 'usuario';
	$action = 'inserir';

	require('controller.php');
?>