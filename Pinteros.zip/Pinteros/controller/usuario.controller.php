<?php
	require_once('conexao/conexao.php');
	require_once('model/usuario.model.php');
	require_once('service/usuario.service.php');

	if ($action == 'buscar') {
		$conexao = new Conexao;
		$usu = new Usuario;

		$usu->__set('login');
		$usu->__set('senha');

		$usuService = new UsuarioService($conexao, $usu);
		$check = $usuService->read();

		if ($check!=null){
			if ($check==$usu) {
				$_SESSION['login'] = $check->login;
				$_SESSION['nome'] = $check->nome;
				$_SESSION['senha'] = $check->senha;
			} else {
				echo "<script>
						$(document).alert('Dados incorretos!');
					</script>";
			}
		}
	}

	 if ($action == 'inserir') {
		

		$conexao = new Conexao;
		$usu = new Usuario;

		$usu->__set('login', $_POST['login']);
		$usu->__set('nome', $_POST['nome']);
		$usu->__set('senha', $_POST['senha']);




		$usuService = new UsuarioService($conexao, $usu);
		$check = $usuService->create();

		if($check!=false){
			header('Location:index.php?link=1');
		} else {
			echo "NÃO FOI POSSÍVEL CADASTRAR";
		}
	}
?>