<?php
	require_once('conexao/conexao.php');
	require_once('model/imagem.model.php');
	require_once('service/imagem.service.php');
?>