create database pinterosDB;
use pinterosDB;

create table usuario(
	id 		integer		primary key	auto_increment	not null,
	login	varchar(25)								not null,
	nome	varchar(50)								not null,
	senha	varchar(20)								not null
);

create table imagem (
	id		integer		primary key auto_increment	not null,
	nome	varchar(25)								not null,
	dataUp	date 									not null,
	ext		char(3)									not null,
	idUsu	integer									not null,
	constraint	fk_Imagem_usu	foreign key (idUsu) references usuario(id)
);