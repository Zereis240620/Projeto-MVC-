<form method="POST" action="cad.php" >
	
	<div class="input-field">
		<input type="text" name="nome" id="nome" value="">
		<label for="nome">Nome</label>
	</div>
	<div class="input-field">
		<input type="text" name="login" id="login" value="">
		<label for="login">Login</label>
	</div>
	<div class="input-field">
		<input type="password" name="senha" id="senha" value="">
		<label for="senha">Senha</label>
	</div>
	<button type="submit"  class="btn waves-effect">Cadastrar</button>
</form>
